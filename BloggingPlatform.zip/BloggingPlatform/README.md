# Blogging + QnA platform

Minor project using Spring boot, hibernate, Thymeleaf.
